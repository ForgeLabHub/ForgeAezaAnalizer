-- Generated from data.json. Run only on empty fixture tables.

BEGIN;

LOCK TABLE public.accounts, public.services, public.transactions IN EXCLUSIVE MODE;

DO $$ BEGIN IF EXISTS (SELECT 1 FROM public.accounts) OR EXISTS (SELECT 1 FROM public.services) OR EXISTS (SELECT 1 FROM public.transactions) THEN RAISE EXCEPTION 'Seed requires empty accounts, services and transactions tables'; END IF; END $$;

INSERT INTO public.accounts ("id", "email", "balance", "withdrawBalance", "totalReplenished", "bonusBalance", "bonusState")
SELECT "id", "email", "balance", "withdrawBalance", "totalReplenished", "bonusBalance", "bonusState" FROM jsonb_populate_recordset(NULL::public.accounts, $fixture_accounts$[
  {
    "id": 1,
    "email": "user-0001@example.test",
    "balance": 83810,
    "withdrawBalance": 14592,
    "totalReplenished": 96922,
    "bonusBalance": 4506,
    "bonusState": "locked"
  },
  {
    "id": 2,
    "email": "user-0002@example.test",
    "balance": 32098,
    "withdrawBalance": 7314,
    "totalReplenished": 105256,
    "bonusBalance": 1679,
    "bonusState": "unlocked"
  },
  {
    "id": 3,
    "email": "user-0003@example.test",
    "balance": 88696,
    "withdrawBalance": 71482,
    "totalReplenished": 134276,
    "bonusBalance": 9674,
    "bonusState": "locked"
  },
  {
    "id": 4,
    "email": "user-0004@example.test",
    "balance": 55302,
    "withdrawBalance": 2082,
    "totalReplenished": 70924,
    "bonusBalance": 1535,
    "bonusState": "unlocked"
  },
  {
    "id": 5,
    "email": "user-0005@example.test",
    "balance": 28657,
    "withdrawBalance": 7623,
    "totalReplenished": 293608,
    "bonusBalance": 9863,
    "bonusState": "locked"
  },
  {
    "id": 6,
    "email": "user-0006@example.test",
    "balance": 3478,
    "withdrawBalance": 2298,
    "totalReplenished": 107726,
    "bonusBalance": 8928,
    "bonusState": "unlocked"
  },
  {
    "id": 7,
    "email": "user-0007@example.test",
    "balance": 54987,
    "withdrawBalance": 14446,
    "totalReplenished": 290501,
    "bonusBalance": 9654,
    "bonusState": "locked"
  },
  {
    "id": 8,
    "email": "user-0008@example.test",
    "balance": 36463,
    "withdrawBalance": 425,
    "totalReplenished": 434296,
    "bonusBalance": 2615,
    "bonusState": "unlocked"
  },
  {
    "id": 9,
    "email": "user-0009@example.test",
    "balance": 91506,
    "withdrawBalance": 55392,
    "totalReplenished": 269895,
    "bonusBalance": 4552,
    "bonusState": "locked"
  },
  {
    "id": 10,
    "email": "user-0010@example.test",
    "balance": 20379,
    "withdrawBalance": 7055,
    "totalReplenished": 420669,
    "bonusBalance": 5514,
    "bonusState": "unlocked"
  }
]$fixture_accounts$::jsonb);

SELECT setval(pg_get_serial_sequence('public.accounts', 'id'), (SELECT max(id) FROM public.accounts), true);

INSERT INTO public.services ("id", "name", "ownerId", "paymentTerm", "autoProlong", "createdAt", "expiresAt", "status", "price")
SELECT "id", "name", "ownerId", "paymentTerm", "autoProlong", "createdAt", "expiresAt", "status", "price" FROM jsonb_populate_recordset(NULL::public.services, $fixture_services$[
  {
    "id": 1,
    "name": "service-0001",
    "ownerId": 1,
    "paymentTerm": "hour",
    "autoProlong": false,
    "createdAt": "2026-10-19T14:30:00.000Z",
    "expiresAt": "2026-10-19T15:30:00.000Z",
    "status": "active",
    "price": 95
  },
  {
    "id": 2,
    "name": "service-0002",
    "ownerId": 2,
    "paymentTerm": "week",
    "autoProlong": false,
    "createdAt": "2026-08-31T15:00:00.000Z",
    "expiresAt": "2026-09-07T15:00:00.000Z",
    "status": "blocked",
    "price": 368
  },
  {
    "id": 3,
    "name": "service-0003",
    "ownerId": 3,
    "paymentTerm": "month",
    "autoProlong": true,
    "createdAt": "2025-09-14T15:00:00.000Z",
    "expiresAt": "2025-10-14T15:00:00.000Z",
    "status": "deleted",
    "price": 353
  },
  {
    "id": 4,
    "name": "service-0004",
    "ownerId": 4,
    "paymentTerm": "quarter_year",
    "autoProlong": false,
    "createdAt": "2026-08-02T15:00:00.000Z",
    "expiresAt": "2026-11-02T15:00:00.000Z",
    "status": "suspended",
    "price": 827
  },
  {
    "id": 5,
    "name": "service-0005",
    "ownerId": 5,
    "paymentTerm": "half_year",
    "autoProlong": false,
    "createdAt": "2025-09-14T15:00:00.000Z",
    "expiresAt": "2026-03-14T15:00:00.000Z",
    "status": "prolong_wait",
    "price": 748
  },
  {
    "id": 6,
    "name": "service-0006",
    "ownerId": 6,
    "paymentTerm": "year",
    "autoProlong": false,
    "createdAt": "2026-10-19T14:30:00.000Z",
    "expiresAt": "2027-10-19T14:30:00.000Z",
    "status": "active",
    "price": 550
  },
  {
    "id": 7,
    "name": "service-0007",
    "ownerId": 7,
    "paymentTerm": "hour",
    "autoProlong": true,
    "createdAt": "2026-10-03T15:00:00.000Z",
    "expiresAt": "2026-10-03T16:00:00.000Z",
    "status": "blocked",
    "price": 945
  },
  {
    "id": 8,
    "name": "service-0008",
    "ownerId": 8,
    "paymentTerm": "week",
    "autoProlong": false,
    "createdAt": "2025-09-14T15:00:00.000Z",
    "expiresAt": "2025-09-21T15:00:00.000Z",
    "status": "deleted",
    "price": 81
  },
  {
    "id": 9,
    "name": "service-0009",
    "ownerId": 9,
    "paymentTerm": "month",
    "autoProlong": false,
    "createdAt": "2026-08-09T15:00:00.000Z",
    "expiresAt": "2026-09-09T15:00:00.000Z",
    "status": "suspended",
    "price": 850
  },
  {
    "id": 10,
    "name": "service-0010",
    "ownerId": 10,
    "paymentTerm": "quarter_year",
    "autoProlong": true,
    "createdAt": "2025-09-14T15:00:00.000Z",
    "expiresAt": "2025-12-14T15:00:00.000Z",
    "status": "prolong_wait",
    "price": 634
  },
  {
    "id": 11,
    "name": "service-0011",
    "ownerId": 1,
    "paymentTerm": "half_year",
    "autoProlong": true,
    "createdAt": "2026-10-19T14:30:00.000Z",
    "expiresAt": "2027-04-19T14:30:00.000Z",
    "status": "active",
    "price": 883
  },
  {
    "id": 12,
    "name": "service-0012",
    "ownerId": 2,
    "paymentTerm": "year",
    "autoProlong": true,
    "createdAt": "2026-09-02T15:00:00.000Z",
    "expiresAt": "2027-09-02T15:00:00.000Z",
    "status": "blocked",
    "price": 197
  },
  {
    "id": 13,
    "name": "service-0013",
    "ownerId": 3,
    "paymentTerm": "hour",
    "autoProlong": true,
    "createdAt": "2025-09-14T15:00:00.000Z",
    "expiresAt": "2025-09-14T16:00:00.000Z",
    "status": "deleted",
    "price": 72
  },
  {
    "id": 14,
    "name": "service-0014",
    "ownerId": 4,
    "paymentTerm": "week",
    "autoProlong": true,
    "createdAt": "2026-10-13T15:00:00.000Z",
    "expiresAt": "2026-10-20T15:00:00.000Z",
    "status": "suspended",
    "price": 234
  },
  {
    "id": 15,
    "name": "service-0015",
    "ownerId": 5,
    "paymentTerm": "month",
    "autoProlong": true,
    "createdAt": "2025-09-14T15:00:00.000Z",
    "expiresAt": "2025-10-14T15:00:00.000Z",
    "status": "prolong_wait",
    "price": 297
  },
  {
    "id": 16,
    "name": "service-0016",
    "ownerId": 6,
    "paymentTerm": "quarter_year",
    "autoProlong": true,
    "createdAt": "2026-10-19T14:30:00.000Z",
    "expiresAt": "2027-01-19T14:30:00.000Z",
    "status": "active",
    "price": 82
  },
  {
    "id": 17,
    "name": "service-0017",
    "ownerId": 7,
    "paymentTerm": "half_year",
    "autoProlong": true,
    "createdAt": "2026-09-19T15:00:00.000Z",
    "expiresAt": "2027-03-19T15:00:00.000Z",
    "status": "blocked",
    "price": 104
  },
  {
    "id": 18,
    "name": "service-0018",
    "ownerId": 8,
    "paymentTerm": "year",
    "autoProlong": false,
    "createdAt": "2025-09-14T15:00:00.000Z",
    "expiresAt": "2026-09-14T15:00:00.000Z",
    "status": "deleted",
    "price": 285
  },
  {
    "id": 19,
    "name": "service-0019",
    "ownerId": 9,
    "paymentTerm": "hour",
    "autoProlong": true,
    "createdAt": "2026-08-21T15:00:00.000Z",
    "expiresAt": "2026-08-21T16:00:00.000Z",
    "status": "suspended",
    "price": 855
  },
  {
    "id": 20,
    "name": "service-0020",
    "ownerId": 10,
    "paymentTerm": "week",
    "autoProlong": false,
    "createdAt": "2025-09-14T15:00:00.000Z",
    "expiresAt": "2025-09-21T15:00:00.000Z",
    "status": "prolong_wait",
    "price": 167
  },
  {
    "id": 21,
    "name": "service-0021",
    "ownerId": 1,
    "paymentTerm": "month",
    "autoProlong": false,
    "createdAt": "2026-10-19T14:30:00.000Z",
    "expiresAt": "2026-11-19T14:30:00.000Z",
    "status": "active",
    "price": 364
  },
  {
    "id": 22,
    "name": "service-0022",
    "ownerId": 2,
    "paymentTerm": "quarter_year",
    "autoProlong": true,
    "createdAt": "2026-09-22T15:00:00.000Z",
    "expiresAt": "2026-12-22T15:00:00.000Z",
    "status": "blocked",
    "price": 274
  },
  {
    "id": 23,
    "name": "service-0023",
    "ownerId": 3,
    "paymentTerm": "half_year",
    "autoProlong": true,
    "createdAt": "2025-09-14T15:00:00.000Z",
    "expiresAt": "2026-03-14T15:00:00.000Z",
    "status": "deleted",
    "price": 960
  },
  {
    "id": 24,
    "name": "service-0024",
    "ownerId": 4,
    "paymentTerm": "year",
    "autoProlong": true,
    "createdAt": "2026-07-23T15:00:00.000Z",
    "expiresAt": "2027-07-23T15:00:00.000Z",
    "status": "suspended",
    "price": 74
  },
  {
    "id": 25,
    "name": "service-0025",
    "ownerId": 5,
    "paymentTerm": "hour",
    "autoProlong": true,
    "createdAt": "2025-09-14T15:00:00.000Z",
    "expiresAt": "2025-09-14T16:00:00.000Z",
    "status": "prolong_wait",
    "price": 651
  },
  {
    "id": 26,
    "name": "service-0026",
    "ownerId": 6,
    "paymentTerm": "week",
    "autoProlong": false,
    "createdAt": "2026-10-19T14:30:00.000Z",
    "expiresAt": "2026-10-26T14:30:00.000Z",
    "status": "active",
    "price": 547
  },
  {
    "id": 27,
    "name": "service-0027",
    "ownerId": 7,
    "paymentTerm": "month",
    "autoProlong": false,
    "createdAt": "2026-09-17T15:00:00.000Z",
    "expiresAt": "2026-10-17T15:00:00.000Z",
    "status": "blocked",
    "price": 474
  },
  {
    "id": 28,
    "name": "service-0028",
    "ownerId": 8,
    "paymentTerm": "quarter_year",
    "autoProlong": false,
    "createdAt": "2025-09-14T15:00:00.000Z",
    "expiresAt": "2025-12-14T15:00:00.000Z",
    "status": "deleted",
    "price": 277
  },
  {
    "id": 29,
    "name": "service-0029",
    "ownerId": 9,
    "paymentTerm": "half_year",
    "autoProlong": true,
    "createdAt": "2026-07-29T15:00:00.000Z",
    "expiresAt": "2027-01-29T15:00:00.000Z",
    "status": "suspended",
    "price": 571
  },
  {
    "id": 30,
    "name": "service-0030",
    "ownerId": 10,
    "paymentTerm": "year",
    "autoProlong": false,
    "createdAt": "2025-09-14T15:00:00.000Z",
    "expiresAt": "2026-09-14T15:00:00.000Z",
    "status": "prolong_wait",
    "price": 702
  }
]$fixture_services$::jsonb);

SELECT setval(pg_get_serial_sequence('public.services', 'id'), (SELECT max(id) FROM public.services), true);

INSERT INTO public.transactions ("id", "amount", "status", "performedAt", "createdAt", "type", "serviceId")
SELECT "id", "amount", "status", "performedAt", "createdAt", "type", "serviceId" FROM jsonb_populate_recordset(NULL::public.transactions, $fixture_transactions$[
  {
    "id": 1,
    "amount": 0,
    "status": "performed",
    "performedAt": "2026-10-19T14:32:54.000Z",
    "createdAt": "2026-10-19T14:32:00.000Z",
    "type": "order",
    "serviceId": 1
  },
  {
    "id": 2,
    "amount": 1000,
    "status": "performed",
    "performedAt": "2026-08-31T15:00:15.000Z",
    "createdAt": "2026-08-31T15:00:00.000Z",
    "type": "order",
    "serviceId": 2
  },
  {
    "id": 3,
    "amount": 824,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2025-09-14T15:00:00.000Z",
    "type": "order",
    "serviceId": 3
  },
  {
    "id": 4,
    "amount": 410,
    "status": "performed",
    "performedAt": "2026-08-02T15:02:18.000Z",
    "createdAt": "2026-08-02T15:02:00.000Z",
    "type": "order",
    "serviceId": 4
  },
  {
    "id": 5,
    "amount": 216,
    "status": "performed",
    "performedAt": "2025-09-14T15:00:59.000Z",
    "createdAt": "2025-09-14T15:00:00.000Z",
    "type": "order",
    "serviceId": 5
  },
  {
    "id": 6,
    "amount": 897,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2026-10-19T14:34:00.000Z",
    "type": "order",
    "serviceId": 6
  },
  {
    "id": 7,
    "amount": 322,
    "status": "performed",
    "performedAt": "2026-10-03T15:05:14.000Z",
    "createdAt": "2026-10-03T15:05:00.000Z",
    "type": "order",
    "serviceId": 7
  },
  {
    "id": 8,
    "amount": 511,
    "status": "performed",
    "performedAt": "2025-09-14T15:05:26.000Z",
    "createdAt": "2025-09-14T15:05:00.000Z",
    "type": "order",
    "serviceId": 8
  },
  {
    "id": 9,
    "amount": 469,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2026-08-09T15:05:00.000Z",
    "type": "order",
    "serviceId": 9
  },
  {
    "id": 10,
    "amount": 271,
    "status": "performed",
    "performedAt": "2025-09-14T15:01:09.000Z",
    "createdAt": "2025-09-14T15:01:00.000Z",
    "type": "order",
    "serviceId": 10
  },
  {
    "id": 11,
    "amount": 762,
    "status": "performed",
    "performedAt": "2026-10-19T14:31:36.000Z",
    "createdAt": "2026-10-19T14:31:00.000Z",
    "type": "order",
    "serviceId": 11
  },
  {
    "id": 12,
    "amount": 269,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2026-09-02T15:04:00.000Z",
    "type": "order",
    "serviceId": 12
  },
  {
    "id": 13,
    "amount": 598,
    "status": "performed",
    "performedAt": "2025-09-14T15:05:28.000Z",
    "createdAt": "2025-09-14T15:05:00.000Z",
    "type": "order",
    "serviceId": 13
  },
  {
    "id": 14,
    "amount": 408,
    "status": "performed",
    "performedAt": "2026-10-13T15:04:24.000Z",
    "createdAt": "2026-10-13T15:04:00.000Z",
    "type": "order",
    "serviceId": 14
  },
  {
    "id": 15,
    "amount": 141,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2025-09-14T15:01:00.000Z",
    "type": "order",
    "serviceId": 15
  },
  {
    "id": 16,
    "amount": 505,
    "status": "performed",
    "performedAt": "2026-10-19T14:34:06.000Z",
    "createdAt": "2026-10-19T14:34:00.000Z",
    "type": "order",
    "serviceId": 16
  },
  {
    "id": 17,
    "amount": 881,
    "status": "performed",
    "performedAt": "2026-09-19T15:00:08.000Z",
    "createdAt": "2026-09-19T15:00:00.000Z",
    "type": "order",
    "serviceId": 17
  },
  {
    "id": 18,
    "amount": 642,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2025-09-14T15:01:00.000Z",
    "type": "order",
    "serviceId": 18
  },
  {
    "id": 19,
    "amount": 811,
    "status": "performed",
    "performedAt": "2026-08-21T15:01:44.000Z",
    "createdAt": "2026-08-21T15:01:00.000Z",
    "type": "order",
    "serviceId": 19
  },
  {
    "id": 20,
    "amount": 610,
    "status": "performed",
    "performedAt": "2025-09-14T15:03:05.000Z",
    "createdAt": "2025-09-14T15:03:00.000Z",
    "type": "order",
    "serviceId": 20
  },
  {
    "id": 21,
    "amount": 390,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2026-10-19T14:33:00.000Z",
    "type": "order",
    "serviceId": 21
  },
  {
    "id": 22,
    "amount": 479,
    "status": "performed",
    "performedAt": "2026-09-22T15:04:34.000Z",
    "createdAt": "2026-09-22T15:04:00.000Z",
    "type": "order",
    "serviceId": 22
  },
  {
    "id": 23,
    "amount": 994,
    "status": "performed",
    "performedAt": "2025-09-14T15:02:36.000Z",
    "createdAt": "2025-09-14T15:02:00.000Z",
    "type": "order",
    "serviceId": 23
  },
  {
    "id": 24,
    "amount": 696,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2026-07-23T15:00:00.000Z",
    "type": "order",
    "serviceId": 24
  },
  {
    "id": 25,
    "amount": 117,
    "status": "performed",
    "performedAt": "2025-09-14T15:05:44.000Z",
    "createdAt": "2025-09-14T15:05:00.000Z",
    "type": "order",
    "serviceId": 25
  },
  {
    "id": 26,
    "amount": 768,
    "status": "performed",
    "performedAt": "2026-10-19T14:34:18.000Z",
    "createdAt": "2026-10-19T14:34:00.000Z",
    "type": "order",
    "serviceId": 26
  },
  {
    "id": 27,
    "amount": 348,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2026-09-17T15:05:00.000Z",
    "type": "order",
    "serviceId": 27
  },
  {
    "id": 28,
    "amount": 300,
    "status": "performed",
    "performedAt": "2025-09-14T15:00:28.000Z",
    "createdAt": "2025-09-14T15:00:00.000Z",
    "type": "order",
    "serviceId": 28
  },
  {
    "id": 29,
    "amount": 464,
    "status": "performed",
    "performedAt": "2026-07-29T15:01:01.000Z",
    "createdAt": "2026-07-29T15:01:00.000Z",
    "type": "order",
    "serviceId": 29
  },
  {
    "id": 30,
    "amount": 896,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2025-09-14T15:05:00.000Z",
    "type": "order",
    "serviceId": 30
  },
  {
    "id": 31,
    "amount": 269,
    "status": "performed",
    "performedAt": "2026-10-19T14:35:33.000Z",
    "createdAt": "2026-10-19T14:35:00.000Z",
    "type": "prolong",
    "serviceId": 1
  },
  {
    "id": 32,
    "amount": 519,
    "status": "performed",
    "performedAt": "2026-08-31T15:01:59.000Z",
    "createdAt": "2026-08-31T15:01:00.000Z",
    "type": "prolong",
    "serviceId": 2
  },
  {
    "id": 33,
    "amount": 891,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2025-09-14T15:00:00.000Z",
    "type": "prolong",
    "serviceId": 3
  },
  {
    "id": 34,
    "amount": 305,
    "status": "performed",
    "performedAt": "2026-08-02T15:05:54.000Z",
    "createdAt": "2026-08-02T15:05:00.000Z",
    "type": "prolong",
    "serviceId": 4
  },
  {
    "id": 35,
    "amount": 519,
    "status": "performed",
    "performedAt": "2025-09-14T15:05:39.000Z",
    "createdAt": "2025-09-14T15:05:00.000Z",
    "type": "prolong",
    "serviceId": 5
  },
  {
    "id": 36,
    "amount": 156,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2026-10-19T14:31:00.000Z",
    "type": "prolong",
    "serviceId": 6
  },
  {
    "id": 37,
    "amount": 780,
    "status": "performed",
    "performedAt": "2026-10-03T15:02:11.000Z",
    "createdAt": "2026-10-03T15:02:00.000Z",
    "type": "prolong",
    "serviceId": 7
  },
  {
    "id": 38,
    "amount": 976,
    "status": "performed",
    "performedAt": "2025-09-14T15:04:50.000Z",
    "createdAt": "2025-09-14T15:04:00.000Z",
    "type": "prolong",
    "serviceId": 8
  },
  {
    "id": 39,
    "amount": 940,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2026-08-09T15:04:00.000Z",
    "type": "prolong",
    "serviceId": 9
  },
  {
    "id": 40,
    "amount": 613,
    "status": "performed",
    "performedAt": "2025-09-14T15:00:21.000Z",
    "createdAt": "2025-09-14T15:00:00.000Z",
    "type": "prolong",
    "serviceId": 10
  },
  {
    "id": 41,
    "amount": 19,
    "status": "performed",
    "performedAt": "2026-10-19T14:33:08.000Z",
    "createdAt": "2026-10-19T14:33:00.000Z",
    "type": "prolong",
    "serviceId": 11
  },
  {
    "id": 42,
    "amount": 899,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2026-09-02T15:02:00.000Z",
    "type": "prolong",
    "serviceId": 12
  },
  {
    "id": 43,
    "amount": 245,
    "status": "performed",
    "performedAt": "2025-09-14T15:02:04.000Z",
    "createdAt": "2025-09-14T15:02:00.000Z",
    "type": "prolong",
    "serviceId": 13
  },
  {
    "id": 44,
    "amount": 899,
    "status": "performed",
    "performedAt": "2026-10-13T15:01:37.000Z",
    "createdAt": "2026-10-13T15:01:00.000Z",
    "type": "prolong",
    "serviceId": 14
  },
  {
    "id": 45,
    "amount": 87,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2025-09-14T15:00:00.000Z",
    "type": "prolong",
    "serviceId": 15
  },
  {
    "id": 46,
    "amount": 497,
    "status": "performed",
    "performedAt": "2026-10-19T14:35:53.000Z",
    "createdAt": "2026-10-19T14:35:00.000Z",
    "type": "prolong",
    "serviceId": 16
  },
  {
    "id": 47,
    "amount": 778,
    "status": "performed",
    "performedAt": "2026-09-19T15:00:35.000Z",
    "createdAt": "2026-09-19T15:00:00.000Z",
    "type": "prolong",
    "serviceId": 17
  },
  {
    "id": 48,
    "amount": 131,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2025-09-14T15:01:00.000Z",
    "type": "prolong",
    "serviceId": 18
  },
  {
    "id": 49,
    "amount": 486,
    "status": "performed",
    "performedAt": "2026-08-21T15:05:36.000Z",
    "createdAt": "2026-08-21T15:05:00.000Z",
    "type": "prolong",
    "serviceId": 19
  },
  {
    "id": 50,
    "amount": 271,
    "status": "performed",
    "performedAt": "2025-09-14T15:01:34.000Z",
    "createdAt": "2025-09-14T15:01:00.000Z",
    "type": "prolong",
    "serviceId": 20
  },
  {
    "id": 51,
    "amount": 433,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2026-10-19T14:34:00.000Z",
    "type": "prolong",
    "serviceId": 21
  },
  {
    "id": 52,
    "amount": 951,
    "status": "performed",
    "performedAt": "2026-09-22T15:01:35.000Z",
    "createdAt": "2026-09-22T15:01:00.000Z",
    "type": "prolong",
    "serviceId": 22
  },
  {
    "id": 53,
    "amount": 706,
    "status": "performed",
    "performedAt": "2025-09-14T15:05:13.000Z",
    "createdAt": "2025-09-14T15:05:00.000Z",
    "type": "prolong",
    "serviceId": 23
  },
  {
    "id": 54,
    "amount": 319,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2026-07-23T15:05:00.000Z",
    "type": "prolong",
    "serviceId": 24
  },
  {
    "id": 55,
    "amount": 687,
    "status": "performed",
    "performedAt": "2025-09-14T15:03:42.000Z",
    "createdAt": "2025-09-14T15:03:00.000Z",
    "type": "prolong",
    "serviceId": 25
  },
  {
    "id": 56,
    "amount": 448,
    "status": "performed",
    "performedAt": "2026-10-19T14:32:58.000Z",
    "createdAt": "2026-10-19T14:32:00.000Z",
    "type": "prolong",
    "serviceId": 26
  },
  {
    "id": 57,
    "amount": 462,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2026-09-17T15:04:00.000Z",
    "type": "prolong",
    "serviceId": 27
  },
  {
    "id": 58,
    "amount": 253,
    "status": "performed",
    "performedAt": "2025-09-14T15:00:15.000Z",
    "createdAt": "2025-09-14T15:00:00.000Z",
    "type": "prolong",
    "serviceId": 28
  },
  {
    "id": 59,
    "amount": 346,
    "status": "performed",
    "performedAt": "2026-07-29T15:00:02.000Z",
    "createdAt": "2026-07-29T15:00:00.000Z",
    "type": "prolong",
    "serviceId": 29
  },
  {
    "id": 60,
    "amount": 567,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2025-09-14T15:04:00.000Z",
    "type": "prolong",
    "serviceId": 30
  },
  {
    "id": 61,
    "amount": 602,
    "status": "performed",
    "performedAt": "2026-10-19T14:31:15.000Z",
    "createdAt": "2026-10-19T14:31:00.000Z",
    "type": "prolong",
    "serviceId": 1
  },
  {
    "id": 62,
    "amount": 72,
    "status": "performed",
    "performedAt": "2026-08-31T15:00:46.000Z",
    "createdAt": "2026-08-31T15:00:00.000Z",
    "type": "prolong",
    "serviceId": 2
  },
  {
    "id": 63,
    "amount": 60,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2025-09-14T15:05:00.000Z",
    "type": "prolong",
    "serviceId": 3
  },
  {
    "id": 64,
    "amount": 69,
    "status": "performed",
    "performedAt": "2026-08-02T15:01:58.000Z",
    "createdAt": "2026-08-02T15:01:00.000Z",
    "type": "prolong",
    "serviceId": 4
  },
  {
    "id": 65,
    "amount": 880,
    "status": "performed",
    "performedAt": "2025-09-14T15:00:22.000Z",
    "createdAt": "2025-09-14T15:00:00.000Z",
    "type": "prolong",
    "serviceId": 5
  },
  {
    "id": 66,
    "amount": 526,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2026-10-19T14:30:00.000Z",
    "type": "prolong",
    "serviceId": 6
  },
  {
    "id": 67,
    "amount": 285,
    "status": "performed",
    "performedAt": "2026-10-03T15:01:43.000Z",
    "createdAt": "2026-10-03T15:01:00.000Z",
    "type": "prolong",
    "serviceId": 7
  },
  {
    "id": 68,
    "amount": 219,
    "status": "performed",
    "performedAt": "2025-09-14T15:03:35.000Z",
    "createdAt": "2025-09-14T15:03:00.000Z",
    "type": "prolong",
    "serviceId": 8
  },
  {
    "id": 69,
    "amount": 740,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2026-08-09T15:01:00.000Z",
    "type": "prolong",
    "serviceId": 9
  },
  {
    "id": 70,
    "amount": 590,
    "status": "performed",
    "performedAt": "2025-09-14T15:04:31.000Z",
    "createdAt": "2025-09-14T15:04:00.000Z",
    "type": "prolong",
    "serviceId": 10
  },
  {
    "id": 71,
    "amount": 803,
    "status": "performed",
    "performedAt": "2026-10-19T14:31:31.000Z",
    "createdAt": "2026-10-19T14:31:00.000Z",
    "type": "prolong",
    "serviceId": 11
  },
  {
    "id": 72,
    "amount": 194,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2026-09-02T15:03:00.000Z",
    "type": "prolong",
    "serviceId": 12
  },
  {
    "id": 73,
    "amount": 99,
    "status": "performed",
    "performedAt": "2025-09-14T15:00:43.000Z",
    "createdAt": "2025-09-14T15:00:00.000Z",
    "type": "prolong",
    "serviceId": 13
  },
  {
    "id": 74,
    "amount": 362,
    "status": "performed",
    "performedAt": "2026-10-13T15:03:28.000Z",
    "createdAt": "2026-10-13T15:03:00.000Z",
    "type": "prolong",
    "serviceId": 14
  },
  {
    "id": 75,
    "amount": 478,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2025-09-14T15:03:00.000Z",
    "type": "prolong",
    "serviceId": 15
  },
  {
    "id": 76,
    "amount": 55,
    "status": "performed",
    "performedAt": "2026-10-19T14:35:44.000Z",
    "createdAt": "2026-10-19T14:35:00.000Z",
    "type": "prolong",
    "serviceId": 16
  },
  {
    "id": 77,
    "amount": 661,
    "status": "performed",
    "performedAt": "2026-09-19T15:05:07.000Z",
    "createdAt": "2026-09-19T15:05:00.000Z",
    "type": "prolong",
    "serviceId": 17
  },
  {
    "id": 78,
    "amount": 412,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2025-09-14T15:00:00.000Z",
    "type": "prolong",
    "serviceId": 18
  },
  {
    "id": 79,
    "amount": 347,
    "status": "performed",
    "performedAt": "2026-08-21T15:05:52.000Z",
    "createdAt": "2026-08-21T15:05:00.000Z",
    "type": "prolong",
    "serviceId": 19
  },
  {
    "id": 80,
    "amount": 254,
    "status": "performed",
    "performedAt": "2025-09-14T15:00:13.000Z",
    "createdAt": "2025-09-14T15:00:00.000Z",
    "type": "prolong",
    "serviceId": 20
  },
  {
    "id": 81,
    "amount": 549,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2026-10-19T14:31:00.000Z",
    "type": "prolong",
    "serviceId": 21
  },
  {
    "id": 82,
    "amount": 143,
    "status": "performed",
    "performedAt": "2026-09-22T15:03:28.000Z",
    "createdAt": "2026-09-22T15:03:00.000Z",
    "type": "prolong",
    "serviceId": 22
  },
  {
    "id": 83,
    "amount": 285,
    "status": "performed",
    "performedAt": "2025-09-14T15:01:30.000Z",
    "createdAt": "2025-09-14T15:01:00.000Z",
    "type": "prolong",
    "serviceId": 23
  },
  {
    "id": 84,
    "amount": 895,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2026-07-23T15:01:00.000Z",
    "type": "prolong",
    "serviceId": 24
  },
  {
    "id": 85,
    "amount": 453,
    "status": "performed",
    "performedAt": "2025-09-14T15:00:52.000Z",
    "createdAt": "2025-09-14T15:00:00.000Z",
    "type": "prolong",
    "serviceId": 25
  },
  {
    "id": 86,
    "amount": 100,
    "status": "performed",
    "performedAt": "2026-10-19T14:34:04.000Z",
    "createdAt": "2026-10-19T14:34:00.000Z",
    "type": "prolong",
    "serviceId": 26
  },
  {
    "id": 87,
    "amount": 553,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2026-09-17T15:05:00.000Z",
    "type": "prolong",
    "serviceId": 27
  },
  {
    "id": 88,
    "amount": 992,
    "status": "performed",
    "performedAt": "2025-09-14T15:00:06.000Z",
    "createdAt": "2025-09-14T15:00:00.000Z",
    "type": "prolong",
    "serviceId": 28
  },
  {
    "id": 89,
    "amount": 170,
    "status": "performed",
    "performedAt": "2026-07-29T15:01:27.000Z",
    "createdAt": "2026-07-29T15:01:00.000Z",
    "type": "prolong",
    "serviceId": 29
  },
  {
    "id": 90,
    "amount": 492,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2025-09-14T15:03:00.000Z",
    "type": "prolong",
    "serviceId": 30
  },
  {
    "id": 91,
    "amount": 885,
    "status": "performed",
    "performedAt": "2026-10-19T14:31:26.000Z",
    "createdAt": "2026-10-19T14:31:00.000Z",
    "type": "prolong",
    "serviceId": 1
  },
  {
    "id": 92,
    "amount": 168,
    "status": "performed",
    "performedAt": "2026-08-31T15:00:25.000Z",
    "createdAt": "2026-08-31T15:00:00.000Z",
    "type": "prolong",
    "serviceId": 2
  },
  {
    "id": 93,
    "amount": 399,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2025-09-14T15:00:00.000Z",
    "type": "prolong",
    "serviceId": 3
  },
  {
    "id": 94,
    "amount": 948,
    "status": "performed",
    "performedAt": "2026-08-02T15:02:51.000Z",
    "createdAt": "2026-08-02T15:02:00.000Z",
    "type": "prolong",
    "serviceId": 4
  },
  {
    "id": 95,
    "amount": 292,
    "status": "performed",
    "performedAt": "2025-09-14T15:03:28.000Z",
    "createdAt": "2025-09-14T15:03:00.000Z",
    "type": "prolong",
    "serviceId": 5
  },
  {
    "id": 96,
    "amount": 980,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2026-10-19T14:35:00.000Z",
    "type": "prolong",
    "serviceId": 6
  },
  {
    "id": 97,
    "amount": 802,
    "status": "performed",
    "performedAt": "2026-10-03T15:05:36.000Z",
    "createdAt": "2026-10-03T15:05:00.000Z",
    "type": "prolong",
    "serviceId": 7
  },
  {
    "id": 98,
    "amount": 735,
    "status": "performed",
    "performedAt": "2025-09-14T15:05:32.000Z",
    "createdAt": "2025-09-14T15:05:00.000Z",
    "type": "prolong",
    "serviceId": 8
  },
  {
    "id": 99,
    "amount": 194,
    "status": "not_performed",
    "performedAt": null,
    "createdAt": "2026-08-09T15:01:00.000Z",
    "type": "prolong",
    "serviceId": 9
  },
  {
    "id": 100,
    "amount": 222,
    "status": "performed",
    "performedAt": "2025-09-14T15:02:04.000Z",
    "createdAt": "2025-09-14T15:02:00.000Z",
    "type": "prolong",
    "serviceId": 10
  }
]$fixture_transactions$::jsonb);

SELECT setval(pg_get_serial_sequence('public.transactions', 'id'), (SELECT max(id) FROM public.transactions), true);

COMMIT;
